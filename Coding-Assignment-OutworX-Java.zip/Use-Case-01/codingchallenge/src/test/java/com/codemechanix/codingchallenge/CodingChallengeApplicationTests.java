package com.codemechanix.codingchallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
